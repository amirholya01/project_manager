<?php
include "router.php";

$request = $_SERVER["REQUEST_URI"];
$router = new Router($request);

$router->get('/', 'site/home');
$router->get('home', 'site/home');
$router->get('product','site/product');
$router->get('AboutUS','site/AboutUS');
$router->get('Contact','site/Contact');
?>

<?php
include 'header.php';
?>











<?php
include 'footer.php';
?>