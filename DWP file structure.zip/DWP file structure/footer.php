
 <!-- FOOTER -->
 <footer>
            <div class="container">
                <div class="footer-top">
                    <div class="row">
                        <div class="col-sm-6 col-md-3 col-xs-b30 col-md-b0">
                            <h6 class="h6 light">About us</h6>
                            <div class="empty-space col-xs-b20"></div>
                            <div class="simple-article size-2 light fulltransparent">Integer posuere orci sit amet feugiat pellent que. Suspendisse vel tempor justo, sit amet</div>
                            <div class="empty-space col-xs-b20"></div>
                        </div>
                        <div class="col-sm-6 col-md-3 col-xs-b30 col-md-b0">
                            <h6 class="h6 light">queck links</h6>
                            <div class="empty-space col-xs-b20"></div>
                            <div class="footer-column-links">
                                <div class="row">
                                    <div class="col-xs-6">
                                        <a href="#">home</a>
                                        <a href="#">about us</a>
                                        <a href="#">products</a>
                                    </div>
                                    <div class="col-xs-6">
                                        <a href="#">privacy policy</a>
                                        <a href="#">warranty</a>
                                        <a href="#">login</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="clear visible-sm"></div>
                        <div class="col-sm-6 col-md-3 col-xs-b30 col-sm-b0">
                            <h6 class="h6 light">Contact</h6>
                            <div class="empty-space col-xs-b20"></div>
                            <div class="footer-post-preview clearfix">
                                <a class="image" href="#"><img src="img/thumbnail-1.jpg" alt="" /></a>
                                <div class="description">
                                    <div class="date">apr 07 / 15</div>
                                    <a class="title">Fusce tincidunt accumsan pretium sit amet</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <h6 class="h6 light">Contact us</h6>
                            <div class="empty-space col-xs-b20"></div>
                                <div class="footer-contact"><i class="fa fa-mobile" aria-hidden="true"></i> contact us: <a href="tel:+35235551238745">+3  (523) 555 123 8745</a></div>
                                <div class="footer-contact"><i class="fa fa-envelope-o" aria-hidden="true"></i> email: <a href="mailto:office@exzo.com">office@exzo.com</a></div>
                                <div class="footer-contact"><i class="fa fa-map-marker" aria-hidden="true"></i> address: <a href="#">Esbjerg 6700, Denmark</a></div>
                        </div>
                    </div>
                    <div class="footer-contact-div">
                        
                    </div>
                </div>
                <div class="footer-bottom">
                    <div class="row">
                        <div class="col-lg-8 col-xs-text-center col-lg-text-left col-xs-b20 col-lg-b0">
                            <div class="copyright">&copy; 2022 All rights reserved. Development by <a href="#" target="_blank">TheCustomTies</a></div>
                            <div class="follow">
                                <a class="entry" href="#"><i class="fa fa-facebook"></i></a>
                                <a class="entry" href="#"><i class="fa fa-twitter"></i></a>
                                <a class="entry" href="#"><i class="fa fa-instagram"></i></a>
                                <a class="entry" href="#"><i class="fa fa-youtube"></i></a>
                                <a class="entry" href="#"><i class="fa fa-snapchat"></i></a>
                            </div>
                        </div>
                        <div class="col-lg-4 col-xs-text-center col-lg-text-right">
                            <div class="footer-payment-icons">
                                <a class="entry"><img src="img/thumbnail-4.jpg" alt="" /></a>
                                <a class="entry"><img src="img/thumbnail-5.jpg" alt="" /></a>
                                <a class="entry"><img src="img/thumbnail-6.jpg" alt="" /></a>
                                <a class="entry"><img src="img/thumbnail-7.jpg" alt="" /></a>
                                <a class="entry"><img src="img/thumbnail-8.jpg" alt="" /></a>
                                <a class="entry"><img src="img/thumbnail-9.jpg" alt="" /></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>


</div>



    <script src="js/jquery-2.2.4.min.js"></script>
    <script src="js/swiper.jquery.min.js"></script>
    <script src="js/global.js"></script>

    <!-- styled select -->
    <script src="js/jquery.sumoselect.min.js"></script>

    <!-- counter -->
    <script src="js/jquery.classycountdown.js"></script>
    <script src="js/jquery.knob.js"></script>
    <script src="js/jquery.throttle.js"></script>

</body>
</html>